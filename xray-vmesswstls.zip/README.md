相关教程地址：
视频教程：https://www.youtube.com/@ygkkk
博客地址：https://ygkkk.blogspot.com
Gitlab项目地址：https://gitlab.com/rwkgyg
感谢 https://github.com/wy580477/replit-trojan