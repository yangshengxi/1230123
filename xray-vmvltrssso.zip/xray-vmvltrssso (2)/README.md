基于wy580477的项目进行简单修改
原项目地址：https://github.com/wy580477/replit-trojan